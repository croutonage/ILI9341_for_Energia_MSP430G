Seeed ILI9341 2.2 TFT+SD library

http://www.ebay.com/itm/Hot-sale-2-2-inch-Serial-SPI-TFT-Color-240X320-LCD-Module-ILI9341-Driver-IC-/360699426541?pt=LH_DefaultDomain_0&hash=item53fb5c76ed

Pinout:

(Energia: TFT)

P2_0 -> LCD_CS

P1_4 -> LCD_DC

P2_2 -> LCD_LED

P1_0 -> LCD_RESET

VCC -> LCD_VCC

GND -> LCD_GND
